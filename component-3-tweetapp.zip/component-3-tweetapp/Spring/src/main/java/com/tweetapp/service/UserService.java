package com.tweetapp.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.tweetapp.entity.ViewUser;
import com.tweetapp.entity.Login;
import com.tweetapp.entity.UserTweet;
import com.tweetapp.entity.Users;
import com.tweetapp.repository.UsersDisplayRepo;
import com.tweetapp.repository.UsersRepo;

@Service
public class UserService {

	@Autowired
	UsersRepo usersRepo;
	@Autowired
	UsersDisplayRepo userDisplayRepo;
	
	public Users registerUser(Users user) {
		// TODO Auto-generated method stub
		
		return usersRepo.save(user);
		
	}
	public List<ViewUser> getUserDetails() {
		// TODO Auto-generated method stub
		List<Users> obj = (List<Users>) usersRepo.findAll(); 
		List<ViewUser> detailsList = new ArrayList<>();
		
		for(int i=0;i<obj.size();i++)
		{
			ViewUser pojo = new ViewUser();
			pojo.setFirstName(obj.get(i).getFirstName());
			pojo.setLastName(obj.get(i).getLastName());
			pojo.setEmail(obj.get(i).getEmail());
			pojo.setUserId(obj.get(i).getUserId());
			pojo.setContactNumber(obj.get(i).getContactNumber());
			detailsList.add(pojo);
		}
		return detailsList;
	}
	public ViewUser getUser(String userId) {
		// TODO Auto-generated method stub
		Users obj = userDisplayRepo.findByUserId(userId);
		ViewUser user = new ViewUser(obj.getFirstName(),obj.getLastName(),obj.getEmail(),obj.getUserId(),obj.getContactNumber());
	return user;
	}

	/*
	 * public void updateUser(Users user) { // TODO Auto-generated method stub Query
	 * query = new Query();
	 * 
	 * query.addCriteria(Criteria.where("userId").is(user.getUserId()));
	 * query.fields().include("userId"); Update update = new Update();
	 * update.set("firstName",user.getFirstName());
	 * update.set("lastName",user.getLastName());
	 * update.set("contactNumber",user.getContactNumber());
	 * mongoOperations.updateFirst(query, update, UserTweet.class); }
	 */
	public Boolean checkCredentials(Login login) {
		// TODO Auto-generated method stub
		boolean status = false;
		List<Users> user = (List<Users>) usersRepo.findAll();
		for(int i=0;i<user.size();i++)
		{
		if(user.get(i).getPassword().equals(login.getPassword())&&user.get(i).getUserId().equals(login.getUserId()))
		{
			status = true;
		}
		}
		
		return status;
	}
	public ViewUser getUserDetail(String userId) {
		// TODO Auto-generated method stub
		
		Users obj = userDisplayRepo.findByUserId(userId);
		ViewUser user = new ViewUser(obj.getFirstName(),obj.getLastName(),obj.getEmail(),obj.getUserId(),obj.getContactNumber());
		
		return user;
	}
	
	/*
	 * public void updateUserPassword(Login login) { // TODO Auto-generated method
	 * stub // TODO Auto-generated method stub Query query = new Query();
	 * 
	 * query.addCriteria(Criteria.where("userId").is(login.getUserId()));
	 * query.fields().include("userId"); Update update = new Update();
	 * update.set("password",login.getPassword());
	 * 
	 * mongoOperations.updateFirst(query, update, UserTweet.class); }
	 */
	public Users findUserById(String userId) {
		// TODO Auto-generated method stub
		Users user = new Users();
		try {
			user =  usersRepo.findByUserId(userId);
		}
		catch (Exception e) {
			user.setUserId(null);
		}
		finally {
			
		}
		return user;
	}

}
