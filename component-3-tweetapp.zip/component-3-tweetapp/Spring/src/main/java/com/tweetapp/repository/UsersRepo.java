package com.tweetapp.repository;
import com.tweetapp.entity.ViewUser;

import org.socialsignin.spring.data.dynamodb.repository.EnableScan;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Repository;

import com.tweetapp.entity.Users;
@EnableScan
@Repository
public interface UsersRepo extends PagingAndSortingRepository<Users,String> {

	Users findByUserId(String userId);

	

}
