package com.tweetapp.repository;

import java.util.List;

import org.socialsignin.spring.data.dynamodb.repository.EnableScan;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Repository;

import com.tweetapp.entity.TweetReply;
import com.tweetapp.entity.UserTweet;

@EnableScan
@Repository
public interface TweetRepo extends PagingAndSortingRepository<UserTweet,String>{

	UserTweet findByTweetId(String tweetId);

	List<UserTweet> findByUserId(String userId);

	void deleteByTweetId(String tweetId);

}
