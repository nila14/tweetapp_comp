package com.tweetapp.repository;

import java.util.List;

import org.socialsignin.spring.data.dynamodb.repository.EnableScan;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Repository;

import com.tweetapp.entity.Like;
import com.tweetapp.entity.TweetReply;

@EnableScan
@Repository
public interface ReplyTweetRepo extends PagingAndSortingRepository<TweetReply,String> {

	@SuppressWarnings("unchecked")
	TweetReply save(TweetReply tweetReply);

	List<TweetReply> findByTweetId(String tweetId);
}
